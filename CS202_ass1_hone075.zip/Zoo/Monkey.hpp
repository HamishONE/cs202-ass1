#ifndef MONKEY_HPP
#define MONKEY_HPP

#include "Animal.hpp"

class Monkey : public Animal {
public:
    Monkey();
};

#endif /* end of include guard: MONKEY_HPP */