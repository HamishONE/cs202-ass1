#ifndef LION_HPP
#define LION_HPP

#include "Animal.hpp"

class Lion : public Animal {
public:
    Lion();
};

#endif /* end of include guard: LION_HPP */