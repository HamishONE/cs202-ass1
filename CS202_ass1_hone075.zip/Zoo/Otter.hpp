#ifndef OTTER_HPP
#define OTTER_HPP

#include "Animal.hpp"

class Otter : public Animal {
public:
    Otter();
};

#endif /* end of include guard: ELEPHANT_HPP */