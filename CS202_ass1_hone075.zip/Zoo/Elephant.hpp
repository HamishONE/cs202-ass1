#ifndef ELEPHANT_HPP
#define ELEPHANT_HPP

#include "Animal.hpp"

class Elephant : public Animal {
public:
    Elephant();
};

#endif /* end of include guard: ELEPHANT_HPP */